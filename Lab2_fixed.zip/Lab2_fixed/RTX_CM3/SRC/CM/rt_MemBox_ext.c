/*----------------------------------------------------------------------------
 *      ECE254 Lab Task Management
 *----------------------------------------------------------------------------
 *      Name:    RT_MEMBOX_ext.C
 *      Purpose: Interface functions for blocking 
 *               fixed memory block management system
 *      Rev.:    V4.60
 *----------------------------------------------------------------------------
 *      This code is extends the RealView Run-Time Library.
 *      Created by University of Waterloo ECE254 Lab Staff.
 *---------------------------------------------------------------------------*/
 
/*----------------------------------------------------------------------------
 *      Includes
 *---------------------------------------------------------------------------*/
 
#include "rt_TypeDef.h"
#include "RTX_Config.h"
#include "rt_System.h"
#include "rt_MemBox.h"
#include "rt_List.h"
#include "rt_HAL_CM.h"
#include "rt_Task.h"       /* added in ECE254 lab keil_proc */ 
#include "rt_Task_ext.h"
#include "rt_MemBox_ext.h" /* added in ECE254 lab keil_proc */   
#include "RTL_ext.h"

/* ECE254 Lab Comment: You may need to include more header files */

/*----------------------------------------------------------------------------
 *      Global Variables
 *---------------------------------------------------------------------------*/

P_TCB wait_task;
struct OS_XCB wait_list;

/*----------------------------------------------------------------------------
 *      Global Functions
 *---------------------------------------------------------------------------*/

/*==========================================================================*/
/*  The following are added for ECE254 Lab Task Management Assignmet       */
/*==========================================================================*/

/*---------------- rt_mem_alloc, task blocks when out of memory-----------*/

/**  
   @brief: Blocking memory allocation routine.
 */

void *rt_mem_alloc (void *mem_pool) {	
	
	void *p;
	p = rt_alloc_box(mem_pool);
	
	P_TCB p_task;
	OS_TID task_id;
	if(p == NULL)
	{
		task_id = rt_tsk_self();
		p_task = os_active_TCB[task_id-1];
		
		rt_put_prio(&wait_list, p_task);
		rt_block(0xffff, WAIT_MEM);
	}
    return p;
}


/*----------- rt_mem_free, pair with _s memory allocators ----------------*/
/**
 * @brief: free memory pointed by ptr, it will unblock a task that is waiting
 *         for memory.
 * @return: OS_R_OK on success and OS_R_NOK if ptr does not belong to gmem_pool 
 */
OS_RESULT rt_mem_free (void *mem_pool, void *box) {
		
		if (rt_free_box(mem_pool,box) == 0){
			
            if (wait_list.p_lnk != NULL){
                wait_task = rt_get_first(&wait_list);
                wait_task->ret_val = (U32)box;
                rt_dispatch(wait_task);
            }
			return OS_R_OK;
		}
		else{
            return (OS_R_NOK);
        }
}
/*----------------------------------------------------------------------------
 * end of file
 *---------------------------------------------------------------------------*/
